﻿namespace TabsControl_Sample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTabWCloseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTabWImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTabWCloseAndImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabsControl1 = new TabsControl_Sample.TabsControl();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addTabToolStripMenuItem,
            this.addTabWCloseToolStripMenuItem,
            this.addTabWImageToolStripMenuItem,
            this.addTabWCloseAndImageToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(500, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addTabToolStripMenuItem
            // 
            this.addTabToolStripMenuItem.Name = "addTabToolStripMenuItem";
            this.addTabToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.addTabToolStripMenuItem.Text = "Add Tab";
            this.addTabToolStripMenuItem.Click += new System.EventHandler(this.addTabToolStripMenuItem_Click);
            // 
            // addTabWCloseToolStripMenuItem
            // 
            this.addTabWCloseToolStripMenuItem.Name = "addTabWCloseToolStripMenuItem";
            this.addTabWCloseToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.addTabWCloseToolStripMenuItem.Text = "Add Tab w/ Close";
            this.addTabWCloseToolStripMenuItem.Click += new System.EventHandler(this.addTabWCloseToolStripMenuItem_Click);
            // 
            // addTabWImageToolStripMenuItem
            // 
            this.addTabWImageToolStripMenuItem.Name = "addTabWImageToolStripMenuItem";
            this.addTabWImageToolStripMenuItem.Size = new System.Drawing.Size(117, 20);
            this.addTabWImageToolStripMenuItem.Text = "Add Tab w/ Image";
            this.addTabWImageToolStripMenuItem.Click += new System.EventHandler(this.addTabWImageToolStripMenuItem_Click);
            // 
            // addTabWCloseAndImageToolStripMenuItem
            // 
            this.addTabWCloseAndImageToolStripMenuItem.Name = "addTabWCloseAndImageToolStripMenuItem";
            this.addTabWCloseAndImageToolStripMenuItem.Size = new System.Drawing.Size(172, 20);
            this.addTabWCloseAndImageToolStripMenuItem.Text = "Add Tab w/ Close and Image";
            this.addTabWCloseAndImageToolStripMenuItem.Click += new System.EventHandler(this.addTabWCloseAndImageToolStripMenuItem_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // tabsControl1
            // 
            this.tabsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabsControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabsControl1.ImageList = this.imageList1;
            this.tabsControl1.ItemSize = new System.Drawing.Size(100, 25);
            this.tabsControl1.Location = new System.Drawing.Point(0, 24);
            this.tabsControl1.Name = "tabsControl1";
            this.tabsControl1.SelectedIndex = 0;
            this.tabsControl1.Size = new System.Drawing.Size(500, 351);
            this.tabsControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabsControl1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 375);
            this.Controls.Add(this.tabsControl1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "MDI Sample";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TabsControl tabsControl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addTabToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTabWCloseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTabWImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTabWCloseAndImageToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
    }
}

