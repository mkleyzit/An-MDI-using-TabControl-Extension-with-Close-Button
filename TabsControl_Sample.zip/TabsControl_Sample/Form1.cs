﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TabsControl_Sample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.imageList1.Images.Add("TabImg", getTabIcon());
        }

        private void addTabToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabsControl1.TabPages.Add(new Tab(getNewTabText())
                {
                    HasCloseButton = false,
                });
        }

        private void addTabWCloseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var tab = new Tab(getNewTabText());
            tab.TabClosed += new EventHandler(tab_TabClosed);
            tabsControl1.TabPages.Add(tab);
        }

        void tab_TabClosed(object sender, EventArgs e)
        {
            var tab = (Tab)sender;
            tab.TabClosed -= tab_TabClosed; //You must call this to prevent memory leaks.
            MessageBox.Show(this, string.Format("{0} was closed. Don't forget to detach handlers.", tab.Text), "TabsControl_Sample"); 
        }

        private void addTabWImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabsControl1.TabPages.Add(new Tab(getNewTabText())
                {
                    HasCloseButton = false,
                    ImageKey = "TabImg",
                });
        }

        private void addTabWCloseAndImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var tab = new Tab(getNewTabText())
            {
                ImageKey = "TabImg",
            };
            tab.TabClosed += new EventHandler(tab_TabClosed);
            tabsControl1.TabPages.Add(tab);
        }

        string getNewTabText()
        {
            return string.Format("Tab {0}", this.tabsControl1.TabPages.Count + 1);
        }

        Image getTabIcon()
        {
            return Image.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(this.GetType(), "tab_icon.png"));
        }
    }
}
